#pragma once
#include "Student.h"
class StudentList
{
private:
	Student student[3];
public:
	StudentList()
	{
		student[0] = Student(1001, "������");
		student[1] = Student(1002, "����ȣ");
		student[2] = Student(1003, "�̼ҷ�");
	};
	~StudentList() {};

	void checkStudent();
};

