#pragma once
#include <iostream>
#include <string>
using namespace std;

class Student
{
private: 
	int id;
	string name;
public:
	Student() { id = 0; name = ' '; };
	Student(int id, string name) { this->id = id; this->name = name; }
	~Student() {};

	int getId() { return id; };
};

