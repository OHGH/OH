#pragma once
#include <iostream>
#include <string>
using namespace std;

class Book
{
private: 
	string bookNum, bookName;
public:
	Book() { bookNum = ' '; bookName = ' '; };
	Book(string bookNum, string bookName) { this->bookNum = bookNum; this->bookName = bookName; };
	~Book() {};
};

