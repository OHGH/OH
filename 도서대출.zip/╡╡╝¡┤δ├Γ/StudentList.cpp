#include "StudentList.h"


void StudentList::checkStudent() 
{
	int id;
	for (int i = 0; i < 3; i++) 
	{
		if (student[i].getId() == id) 
		{
			
		}
	}
}

