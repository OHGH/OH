#pragma once
#include "Book.h"
class BookList
{
private:
	Book book[5];
public:
	BookList() 
	{
		book[0] = Book("B01", "C++");
		book[1] = Book("B02", "Java");
		book[2] = Book("B03", "Java");
		book[3] = Book("B04", "DS");
		book[4] = Book("B05", "CA");
	};
	~BookList() {};
};

