#include "Library.h"

void Library::lendBook(int number, string bookname)
{

	for (int i = 0; i < 5; i++) //3���̻� ����
	{
		if (list[i]->getSnum() == number)
		{
			limit++;
			if (limit == 2)
				limit2 = number;

	for (int i = 0; i < 5; i++) //����å ����
	{
		if (list[i]->getBname() == bookname && bookname!=java2)
		{		}
	}

			if (bookname == "Java"&&limit<1)//����Ʈ �ٽø����
			{
				for (int j = 0; j < count; j++)
				{
					if (list[j]->getBname() == "java")
					{
						if(list[j]->getSnum() != number)//�ϳѹ� 03�ٲٱ� 
						list[count++]->setList(studentList[i]->getNumber(), studentList[i]->getName(), bookList[j]->getBooknum(), bookList[j]->getBookname());
					}
					break;
				}
				break;
			}
			samebook++;
			if (samebook == 1)
				samebook2 = bookname;
		}
	}

	if (number != limit2 && bookname != samebook2 )
	{
		for (int i = 0; i < 3; i++)
		{
			if (studentList[i]->getNumber() == number)
			{
				for (int j = 0; j < 5; j++)
				{
					if (bookList[j]->getBookname() == bookname)
					{
						list[count++]->setList(studentList[i]->getNumber(), studentList[i]->getName(), bookList[j]->getBooknum(), bookList[j]->getBookname());
						break;
					}
					else if (bookList[j]->getBookname() != bookname && j == 4)
						cout << "���� å" << endl;
				}
				break;
			}
			else if (studentList[i]->getNumber() != number && i == 2)
				cout << "���� �л�" << endl;
		}
	}
	else
		cout << "�Ⱥ�����" << endl;
};

void  Library::turnBook(int number, string bookname)//�迭���� �ǵھ��б�
{
	for (int i = 0; i < 3; i++)
	{
		if (list[i]->getSnum() == number)
		{
			for (int j = 0; j < 5; j++)
			{
				if (list[j]->getBname() == bookname)
				{
					for (int k = 0; k < 5; k++)
					{
						list[k] = list[k + 1];
						break;
					}
					count--;
					break;
				}
				else if (list[j]->getBname() != bookname && j == 4)
					cout << "���� å" << endl;
			}
			break;
		}
		else if (list[i]->getSnum() != number && i == 2)
			cout << "���� �л�" << endl;
	}
};

void  Library::print()
{
	for (int i = 0; i < count; i++)
	{
		cout << list[i]->getSnum() << " " << list[i]->getSname() << " [" << list[i]->getBnum() << "] [" << list[i]->getBname() << "]" << endl;
	}
}

