#pragma once
#include <iostream>
#include <string>
using namespace std;

class Student 
{
private:
	int number;
	string name;
public:
	Student() {  int number = 0; string name = "";};
	Student(int number, string name)
	{
		this->number = number;
		this->name = name;
	};
	~Student() {};

	int getNumber() { return number; }
	string getName() { return name; }
};

