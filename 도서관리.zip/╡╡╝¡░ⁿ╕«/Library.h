#pragma once

#include "Book.h"
#include "Student.h"
#include "List.h"

class Library
{
private:
	Book *bookList[5];
	Student *studentList[3];
	List *list[5];
	int count;
	int limit, limit2, samebook,java;
	string samebook2,java2;

public:
	Library()
	{
		count = 0; 
		limit = 0;
		limit2 = 0;
		samebook = 0;
		samebook2 = "";
		java = 0;
		java2 = "";
		bookList[0] = new Book("B01", "C++");
		bookList[1] = new Book("B02", "Java");
		bookList[2] = new Book("B03", "Java");
		bookList[3] = new Book("B04", "DS");
		bookList[4] = new Book("B05", "CA");

		studentList[0] = new Student(1001, "������");
		studentList[1] = new Student(1002, "����ȣ");
		studentList[2] = new Student(1003, "�̼ҷ�");

		for (int i = 0; i < 5; i++)
		{
			list[i] = new List();
		}

	};
	Library(int snum, string sname, string bnum, string bname)
	{
		for (int i = 0; i < 5; i++)
		{
			list[i] = new List(snum,sname, bnum, bname);
		}
	};

	~Library() {};
	
	void lendBook(int number, string bookname);
	void turnBook(int number, string bookname);
	void print();
};

