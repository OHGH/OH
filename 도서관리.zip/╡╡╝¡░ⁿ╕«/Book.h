#pragma once
#include <iostream>
#include <string>
using namespace std;

class Book
{
private:
	string booknum;
	string bookname;
public:
	Book() { string booknum = ""; string bookname = ""; };
	Book(string booknum,string bookname )
	{
		this->booknum = booknum;
		this->bookname = bookname;
	};
	~Book() {};

	string getBooknum() { return booknum; }
	string getBookname() { return bookname; }

};

