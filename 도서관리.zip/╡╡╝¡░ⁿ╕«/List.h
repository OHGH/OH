#pragma once
#include <iostream>
#include <string>
using namespace std;

class List
{
private:
	int snum;
	string sname, bnum, bname;
public:
	List()
	{
		int snum = 0; string sname = ""; string bnum = ""; string bname = "";
	};
	List(int snum, string sname, string bnum, string bname)
	{
		this->snum = snum;
		this->sname = sname;
		this->bnum = bnum;
		this->bname = bname;
	};
	~List() {};

	void setList(int snum, string sname, string bnum, string bname)
	{
		this->snum = snum;
		this->sname = sname;
		this->bnum = bnum;
		this->bname = bname;
	};
	int getSnum() { return snum; }
	string getSname() { return sname; }
	string getBnum() { return bnum; }
	string getBname() { return bname; }
	
	/*int getLend() { return lend; }
	void setLend(int lend) { this->lend = lend; }
	int getCount() { return count; }
	void setCount(int count) { this->count = count; }*/
};

